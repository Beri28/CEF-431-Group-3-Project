from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# Replace these with your actual signup and login URLs
SIGNUP_URL = "http://localhost:5000/register"
LOGIN_URL = "http://localhost:5000/login"

# Replace with your actual test credentials
test_email = "test@example.com"
test_password = "securepassword"

def test_signup(driver):
    driver.get(SIGNUP_URL)

    # Find and fill the signup form
    driver.find_element(By.NAME, "name").send_keys("test")
    driver.find_element(By.NAME, "email").send_keys(test_email)
    driver.find_element(By.NAME, "address").send_keys("molyko")
    driver.find_element(By.NAME, "password").send_keys(test_password)
    driver.find_element(By.NAME, "contact").send_keys("680124356")
    driver.find_element(By.NAME, "account_Type").send_keys("delivery-agent")
    # driver.find_element(By.NAME, "confirm_password").send_keys(test_password)
    driver.find_element(By.ID, "register").click()  # Adjust the button name

    time.sleep(7)  # Wait for the response

    # Verify signup success (update the condition based on your application)

    if "userAccount" in driver.current_url:
        print("Register test passed.")
    else:
        print("Register test failed")

def test_login(driver):
    driver.get(LOGIN_URL)

    # Find and fill the login form
    driver.find_element(By.NAME, "email").send_keys("john@gmail.com")
    driver.find_element(By.NAME, "password").send_keys("12345678")
    driver.find_element(By.ID, "login").click()  # Adjust the button name

    time.sleep(7)  # Wait for the response

    # Verify login success (update the condition based on your application)
    if "userAccount" in driver.current_url:
        print("Login test passed.")
    else:
        print("Login test failed")

def main():
    # Set up the WebDriver (using Chrome in this example)
    driver = webdriver.Edge()
    # driver = webdriver.Chrome()

    try:
        # test_signup(driver)
        # time.sleep(5)
        test_login(driver)
    finally:
        driver.quit()  # Ensure the driver is closed

if __name__ == "__main__":
    main()